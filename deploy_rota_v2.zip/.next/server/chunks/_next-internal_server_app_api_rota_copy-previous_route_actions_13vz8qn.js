module.exports=[46147,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rota_copy-previous_route_actions_13vz8qn.js.map