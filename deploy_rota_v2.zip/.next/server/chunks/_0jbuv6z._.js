module.exports=[51332,e=>{"use strict";var t=e.i(89171),a=e.i(15270),r=e.i(68105),s=e.i(53905),i=e.i(54799),o=e.i(22734),n=e.i(14747);async function l(e){try{let r=await e.json(),l=(r.identifier||r.email||"").trim();if(!l)return t.NextResponse.json({success:!1,message:"Please provide your registered email or username."},{status:400});let d=l.toLowerCase(),c=await a.prisma.user.findFirst({where:{OR:[{email:d},{username:d}]}});if(!c)return t.NextResponse.json({success:!1,message:"No Owner or Manager account found with that email or username."},{status:404});if("business_owner"!==c.role&&"head_office"!==c.role&&"manager"!==c.role)return t.NextResponse.json({success:!1,message:"Only Owner and Manager accounts can reset passwords here. Staff members should contact their site manager."},{status:403});if(!c.email)return t.NextResponse.json({success:!1,message:"This account does not have a registered email address. Please contact your system administrator."},{status:400});let p=i.default.randomInt(1e5,1e6).toString(),u=new Date(Date.now()+9e5);await a.prisma.passwordResetToken.deleteMany({where:{userId:c.id}}).catch(()=>{}),await a.prisma.passwordResetToken.create({data:{userId:c.id,token:p,expiresAt:u}});let g=function(e){let[t,a]=e.split("@");return a?t.length<=2?`${t[0]}***@${a}`:`${t.slice(0,2)}***${t.slice(-1)}@${a}`:e}(c.email),h=[],m="",f="",w=n.default.join(process.cwd(),"public","brand","rotabeat-logo-trimmed.png"),x=n.default.join(process.cwd(),"public","brand","rotabeat-icon-trimmed.png");if(o.default.existsSync(w)){let e=o.default.readFileSync(w);m=`data:image/png;base64,${e.toString("base64")}`,h.push({filename:"rotabeat-logo.png",path:w,cid:"rotabeat-logo",contentType:"image/png"})}if(o.default.existsSync(x)){let e=o.default.readFileSync(x);f=`data:image/png;base64,${e.toString("base64")}`,h.push({filename:"rotabeat-icon.png",path:x,cid:"rotabeat-icon",contentType:"image/png"})}let b="https://rotabeat.com",y=h.some(e=>"rotabeat-logo"===e.cid)?"cid:rotabeat-logo":m||`${b}/brand/rotabeat-logo-trimmed.png`,R=h.some(e=>"rotabeat-icon"===e.cid)?"cid:rotabeat-icon":f||`${b}/brand/rotabeat-icon-trimmed.png`,v=`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Reset Verification Code</title>
      </head>
      <body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f1f5f9; padding: 40px 16px;">
          <tr>
            <td align="center">
              <table width="100%" border="0" cellpadding="0" cellspacing="0" style="max-width: 520px; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.08), 0 2px 4px -2px rgba(0, 0, 0, 0.05); border: 1px solid #e2e8f0;">
                
                <!-- Brand Top Accent Bar -->
                <tr>
                  <td style="height: 5px; background: linear-gradient(90deg, #4F46E5 0%, #7C3AED 50%, #EC4899 100%);"></td>
                </tr>

                <!-- Header with Official RotaBeat Logo -->
                <tr>
                  <td style="background-color: #ffffff; padding: 28px 24px 20px 24px; text-align: center; border-bottom: 1px solid #f1f5f9;">
                    <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                      <tr>
                        <td align="center">
                          <img src="${y}" alt="RotaBeat Logo" width="176" style="display: block; width: 176px; height: auto; border: 0; outline: none; margin: 0 auto;" />
                        </td>
                      </tr>
                    </table>
                    <p style="margin: 8px 0 0 0; color: #64748b; font-size: 13px; font-weight: 500; letter-spacing: 0.2px;">
                      Workforce &amp; Attendance Platform
                    </p>
                  </td>
                </tr>

                <!-- Content Area with RotaBeat Icon -->
                <tr>
                  <td style="padding: 32px 30px;">
                    <table border="0" cellpadding="0" cellspacing="0" style="margin-bottom: 20px;">
                      <tr>
                        <td style="vertical-align: middle; padding-right: 12px;">
                          <img src="${R}" alt="RotaBeat Icon" width="34" style="display: block; width: 34px; height: auto; border: 0;" />
                        </td>
                        <td style="vertical-align: middle;">
                          <h2 style="margin: 0; color: #0f172a; font-size: 20px; font-weight: 700;">
                            Password Reset Verification
                          </h2>
                        </td>
                      </tr>
                    </table>

                    <p style="margin: 0 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                      Hello <strong>${c.name||c.firstName||"there"}</strong>,
                    </p>
                    <p style="margin: 0 0 20px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                      We received a request to reset the password for your <strong>${"business_owner"===c.role?"Business Owner":"Manager"}</strong> account (${c.email}).
                    </p>
                    <p style="margin: 0 0 12px 0; color: #334155; font-size: 14px; font-weight: 600;">
                      Use the 6-digit verification code below to set your new password:
                    </p>

                    <!-- Verification Code Box with Brand Accent -->
                    <table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin: 18px 0 22px 0;">
                      <tr>
                        <td align="center">
                          <div style="background-color: #f8fafc; border: 2px dashed #6366f1; border-radius: 14px; padding: 18px 24px; display: inline-block;">
                            <span style="font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, Courier, monospace; font-size: 36px; font-weight: 800; letter-spacing: 10px; color: #4F46E5; margin-left: 10px;">
                              ${p}
                            </span>
                          </div>
                        </td>
                      </tr>
                    </table>

                    <p style="margin: 0 0 20px 0; color: #64748b; font-size: 13px; line-height: 1.5; text-align: center;">
                      ⏱ This code will expire in <strong>15 minutes</strong>.
                    </p>

                    <div style="background-color: #fef2f2; border-left: 4px solid #ef4444; border-radius: 6px; padding: 12px 16px; margin-top: 24px;">
                      <p style="margin: 0; color: #991b1b; font-size: 12px; line-height: 1.5;">
                        <strong>Security Notice:</strong> Never share this code with anyone. RotaBeat will never ask you for your verification code. If you did not make this request, you can safely ignore this email.
                      </p>
                    </div>
                  </td>
                </tr>

                <!-- Footer with Brand Icon -->
                <tr>
                  <td style="background-color: #f8fafc; padding: 22px 24px; border-top: 1px solid #e2e8f0; text-align: center;">
                    <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto 8px auto;">
                      <tr>
                        <td style="vertical-align: middle; padding-right: 6px;">
                          <img src="${R}" alt="RotaBeat" width="18" style="display: block; width: 18px; height: auto; opacity: 0.85; border: 0;" />
                        </td>
                        <td style="vertical-align: middle;">
                          <span style="color: #475569; font-size: 12px; font-weight: 700; letter-spacing: 0.3px;">RotaBeat Platform</span>
                        </td>
                      </tr>
                    </table>
                    <p style="margin: 0; color: #94a3b8; font-size: 12px;">
                      Fast &middot; Accurate &middot; Compliant Workforce Scheduling &middot; &copy; ${new Date().getFullYear()} RotaBeat
                    </p>
                  </td>
                </tr>

              </table>
            </td>
          </tr>
        </table>
      </body>
      </html>
    `,E=!1;try{E=!!(await (0,s.sendEmailNotification)({to:c.email,subject:`RotaBeat — Your Verification Code: ${p}`,html:v,attachments:h})).success}catch(e){console.error("Email dispatch failed:",e)}return await a.prisma.notificationAuditLog.create({data:{type:"password_reset_code",recipient:c.email,siteId:null,status:E?"SENT":"SIMULATED",reason:E?"Code sent to email.":"Logged (no active SMTP or dev mode)."}}).catch(()=>{}),await a.prisma.auditEvent.create({data:{timestamp:new Date().toISOString(),userName:c.name,role:c.role,siteId:null,entity:"User",action:"PASSWORD_RESET_REQUESTED",previousValue:null,newValue:JSON.stringify({userId:c.id,email:c.email}),reason:"Requested 6-digit password reset verification code",source:"web"}}).catch(()=>{}),t.NextResponse.json({success:!0,message:`A 6-digit verification code has been sent to ${g}.`,maskedEmail:g,identifier:l,devCode:void 0})}catch(e){return console.error("POST /api/auth/reset-password error:",e),t.NextResponse.json({success:!1,message:"Failed to process password reset request. Please try again."},{status:500})}}async function d(e){try{let s,i=await e.json(),o=(i.identifier||i.email||"").trim(),n=(i.code||"").toString().trim(),l=(i.newPassword||"").trim(),d="verify_code"===i.action,c=n.replace(/\D/g,"").slice(0,6);if(6!==c.length)return t.NextResponse.json({success:!1,message:"Please enter a valid 6-digit verification code."},{status:400});if(!d&&(!l||l.length<6))return t.NextResponse.json({success:!1,message:"Password must be at least 6 characters long."},{status:400});if(o){let e=o.toLowerCase(),t=await a.prisma.user.findFirst({where:{OR:[{email:e},{username:e}]},select:{id:!0}});t&&(s=t.id)}let p=await a.prisma.passwordResetToken.findFirst({where:{token:c,usedAt:null,expiresAt:{gt:new Date},...s?{userId:s}:{}},include:{user:!0},orderBy:{createdAt:"desc"}});if(!p){let e=await a.prisma.passwordResetToken.findFirst({where:{token:c,...s?{userId:s}:{}},orderBy:{createdAt:"desc"}});if(e){if(e.usedAt)return t.NextResponse.json({success:!1,message:"This verification code has already been used. Please request a new code."},{status:400});if(e.expiresAt<=new Date)return t.NextResponse.json({success:!1,message:"This verification code has expired. Please request a new code."},{status:400})}return t.NextResponse.json({success:!1,message:"Invalid verification code. Please check your email and try again."},{status:400})}if(d)return t.NextResponse.json({success:!0,message:"Verification code is valid."});let u=await (0,r.hashPassword)(l);return await a.prisma.$transaction([a.prisma.user.update({where:{id:p.userId},data:{passwordHash:u,sessionVersion:{increment:1}}}),a.prisma.passwordResetToken.update({where:{id:p.id},data:{usedAt:new Date}})]),await a.prisma.auditEvent.create({data:{timestamp:new Date().toISOString(),userName:p.user.name,role:p.user.role,siteId:null,entity:"User",action:"PASSWORD_RESET_COMPLETE",previousValue:null,newValue:JSON.stringify({userId:p.userId,email:p.user.email}),reason:"Password reset completed with 6-digit verification code",source:"web"}}).catch(()=>{}),t.NextResponse.json({success:!0,message:"Password reset successfully! You can now sign in with your new password."})}catch(e){return console.error("PUT /api/auth/reset-password error:",e),t.NextResponse.json({success:!1,message:"Failed to reset password. Please try again."},{status:500})}}e.s(["POST",0,l,"PUT",0,d])},18063,e=>{"use strict";var t=e.i(47909),a=e.i(74017),r=e.i(96250),s=e.i(59756),i=e.i(61916),o=e.i(74677),n=e.i(69741),l=e.i(16795),d=e.i(87718),c=e.i(95169),p=e.i(47587),u=e.i(66012),g=e.i(70101),h=e.i(26937),m=e.i(10372),f=e.i(93695);e.i(52474);var w=e.i(220);let x=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/auth/reset-password/route",pathname:"/api/auth/reset-password",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/auth/reset-password/route.ts",nextConfigOutput:"standalone",userland:()=>e.r(51332),...{}}),{workAsyncStorage:b,workUnitAsyncStorage:y,serverHooks:R}=x;async function v(e,t,r){r.requestMeta&&(0,s.setRequestMeta)(e,r.requestMeta),x.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let b="/api/auth/reset-password/route";b=b.replace(/\/index$/,"")||"/";let y=await x.prepare(e,t,{srcPage:b,multiZoneDraftMode:!1});if(!y)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:R,deploymentId:v,params:E,nextConfig:S,parsedUrl:C,isDraftMode:T,prerenderManifest:P,routerServerContext:A,isOnDemandRevalidate:N,revalidateOnlyGenerated:k,resolvedPathname:I,clientReferenceManifest:O,serverActionsManifest:_}=y,D=(0,n.normalizeAppPath)(b),M=!!(P.dynamicRoutes[D]||P.routes[I]),$=async()=>((null==A?void 0:A.render404)?await A.render404(e,t,C,!1):t.end("This page could not be found"),null);if(M&&!T){let e=!!P.routes[I],t=P.dynamicRoutes[D];if(t&&!1===t.fallback&&!e){if(S.adapterPath)return await $();throw new f.NoFallbackError}}let j=null;!M||x.isDev||T||(j="/index"===(j=I)?"/":j);let q=!0===x.isDev||!M,B=M&&!q;_&&O&&(0,o.setManifestsSingleton)({page:b,clientReferenceManifest:O,serverActionsManifest:_});let F=e.method||"GET",H=(0,i.getTracer)(),U=H.getActiveScopeSpan(),L=!!(null==A?void 0:A.isWrappedByNextServer),V=!!(0,s.getRequestMeta)(e,"minimalMode"),z=(0,s.getRequestMeta)(e,"incrementalCache")||await x.getIncrementalCache(e,S,P,V);null==z||z.resetRequestCache(),globalThis.__incrementalCache=z;let K={params:E,previewProps:P.preview,renderOpts:{experimental:{authInterrupts:!!S.experimental.authInterrupts,useCacheTimeout:S.experimental.useCacheTimeout},cacheComponents:!!S.cacheComponents,validationLevel:S.experimental.instantInsights.validationLevel,supportsDynamicResponse:q,incrementalCache:z,hmrRefreshHash:(0,s.getRequestMeta)(e,"hmrRefreshHash"),cacheLifeProfiles:S.cacheLife,staticPageGenerationTimeout:S.staticPageGenerationTimeout,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,s)=>x.onRequestError(e,t,r,s,A)},sharedContext:{buildId:R,deploymentId:v}},W=new l.NodeNextRequest(e),G=new l.NodeNextResponse(t),Y=d.NextRequestAdapter.fromNodeNextRequest(W,(0,d.signalFromNodeResponse)(t)),X=async({previousCacheEntry:a})=>{try{if(!V&&N&&k&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await x.handle(Y,K);e.fetchMetrics=K.renderOpts.fetchMetrics;let i=K.renderOpts.pendingWaitUntil;i&&r.waitUntil&&(r.waitUntil(i),i=void 0);let o=K.renderOpts.collectedTags;if(!M)return await (0,u.sendResponse)(W,G,s,i),null;{let e=await s.blob(),t=(0,g.toNodeOutgoingHttpHeaders)(s.headers);o&&(t[m.NEXT_CACHE_TAGS_HEADER]=o),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,r=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=m.INFINITE_CACHE?!1!==a&&a>0?S.expireTime:void 0:K.renderOpts.collectedExpire;return{value:{kind:w.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await x.onRequestError(e,t,{routerKind:"App Router",routePath:b,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:B,isOnDemandRevalidate:N})},!1,A),t}},J=async(s,o)=>{try{var n,l;let s=await x.handleResponse({req:e,nextConfig:S,cacheKey:j,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:P,isRoutePPREnabled:!1,isOnDemandRevalidate:N,revalidateOnlyGenerated:k,responseGenerator:X,waitUntil:r.waitUntil,isMinimalMode:V});if(!M)return;if((null==s||null==(n=s.value)?void 0:n.kind)!==w.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==s||null==(l=s.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});V||t.setHeader("x-nextjs-cache",N?"REVALIDATED":s.isMiss?"MISS":s.isStale?"STALE":"HIT"),T&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let i=(0,g.fromNodeOutgoingHttpHeaders)(s.value.headers);V&&M||i.delete(m.NEXT_CACHE_TAGS_HEADER),!s.cacheControl||t.getHeader("Cache-Control")||i.get("Cache-Control")||i.set("Cache-Control",(0,h.getCacheControlHeader)(s.cacheControl)),await (0,u.sendResponse)(W,G,new Response(s.value.body,{headers:i,status:s.value.status||200}));return}catch(t){if(t instanceof f.NoFallbackError||await x.onRequestError(e,t,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:B,isOnDemandRevalidate:N})},!1,A),M)throw t;await (0,u.sendResponse)(W,G,new Response(null,{status:500}));return}finally{(()=>{if(!s)return;let e=t.statusCode;s.setAttributes({"http.status_code":e,"next.rsc":!1}),e&&e>=500&&(s.setStatus({code:i.SpanStatusCode.ERROR}),s.setAttribute("error.type",e.toString()));let a=H.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==c.BaseServerSpan.handleRequest)return console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route")||D,n=`${F} ${r}`;s.setAttributes({"next.route":r,"http.route":r,"next.span_name":n}),s.updateName(n),o&&o!==s&&(o.setAttribute("http.route",r),o.updateName(n))})()}};if(L&&U)await J(U,void 0);else{let t=H.getActiveScopeSpan();await H.withPropagatedContext(e.headers,()=>H.trace(c.BaseServerSpan.handleRequest,{spanName:`${F} ${b}`,kind:i.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},e=>J(e,t)),void 0,!L)}}e.s(["handler",0,v,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:b,workUnitAsyncStorage:y})},"routeModule",0,x,"serverHooks",0,R,"workAsyncStorage",0,b,"workUnitAsyncStorage",0,y])}];

//# sourceMappingURL=_0jbuv6z._.js.map