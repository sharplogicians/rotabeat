module.exports=[34445,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_approval_page_actions_1fjnh3f.js.map