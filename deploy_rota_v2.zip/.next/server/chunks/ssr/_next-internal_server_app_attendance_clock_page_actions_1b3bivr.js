module.exports=[97314,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_attendance_clock_page_actions_1b3bivr.js.map