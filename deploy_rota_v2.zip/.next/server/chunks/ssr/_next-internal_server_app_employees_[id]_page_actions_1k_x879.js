module.exports=[48235,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_employees_%5Bid%5D_page_actions_1k_x879.js.map