module.exports=[18777,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_head-office_page_actions_1fzwfs0.js.map