module.exports=[30948,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_managers_page_actions_1jooqhr.js.map