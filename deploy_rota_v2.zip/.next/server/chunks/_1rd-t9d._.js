module.exports=[50832,e=>{"use strict";var t=e.i(89171),a=e.i(15270),s=e.i(68105),r=e.i(23926),i=e.i(10839),o=e.i(53905),n=e.i(22734),l=e.i(14747);async function d(){let e=await a.prisma.employee.findMany({select:{employeeNumber:!0}}),t=1e3;for(let a of e){let e=parseInt(a.employeeNumber.replace(/\D/g,""),10);!isNaN(e)&&e>t&&(t=e)}return`EMP-${t+1}`}async function p(e){try{let{searchParams:s}=new URL(e.url),i=s.get("siteId"),o=(0,r.getApiUser)(e),n=i;if(o)try{n=(0,r.enforceSiteAccess)(o,"all"===i?void 0:i)||null}catch(e){if(e instanceof Response||e&&e.status)return e}let l={};n&&"all"!==n&&(l.primarySiteId=n);let d=await a.prisma.employee.findMany({where:l,orderBy:{lastName:"asc"},select:{id:!0,employeeNumber:!0,firstName:!0,lastName:!0,email:!0,phone:!0,jobTitle:!0,profileImage:!0,faceEmbedding:!0,primarySiteId:!0,managerId:!0,payType:!0,hourlyRate:!0,salaryAnnual:!0,startDate:!0,status:!0,leavingDate:!0,leavingReason:!0,pinSet:!0,pin:!0,createdAt:!0,primarySite:{select:{id:!0,name:!0,town:!0}}}});return t.NextResponse.json({success:!0,employees:d})}catch(e){return console.error("GET /api/employees error:",e),t.NextResponse.json({success:!1,message:"Failed to retrieve employees."},{status:500})}}async function m(e){try{let p=(0,r.getApiUser)(e),m=await e.json(),{employeeNumber:c,firstName:u,lastName:g,email:f,phone:y,jobTitle:h,profileImage:b,primarySiteId:x,managerId:w,payType:R,hourlyRate:N,salaryAnnual:E,startDate:v,status:T,password:S,pin:A}=m;if(!b||"string"!=typeof b||!b.trim())return t.NextResponse.json({success:!1,message:"Profile image is compulsory when adding an employee."},{status:400});if(!b.startsWith("data:image/"))return t.NextResponse.json({success:!1,message:"Profile image must be a valid data URI (data:image/...)."},{status:400});if(b.length>14e5)return t.NextResponse.json({success:!1,message:"Profile image must be less than 1 MB."},{status:400});if(!u||!u.trim())return t.NextResponse.json({success:!1,message:"First name is required."},{status:400});if(!g||!g.trim())return t.NextResponse.json({success:!1,message:"Last name is required."},{status:400});if(!f||!f.trim())return t.NextResponse.json({success:!1,message:"Email is required."},{status:400});if(!h||!h.trim())return t.NextResponse.json({success:!1,message:"Job title is required."},{status:400});if(!x)return t.NextResponse.json({success:!1,message:"Primary site is required."},{status:400});if(!v)return t.NextResponse.json({success:!1,message:"Start date is required."},{status:400});if(p)try{(0,r.enforceSiteAccess)(p,x)}catch(e){if(e instanceof Response||e&&e.status)return e}let I=f.trim().toLowerCase(),j="Site Manager"===h.trim();if(j&&(!S||!S.trim()))return t.NextResponse.json({success:!1,message:"Password is required when creating a Site Manager."},{status:400});let P=await a.prisma.location.findUnique({where:{id:x}});if(!P)return t.NextResponse.json({success:!1,message:"Selected location was not found in database."},{status:400});if(j&&await a.prisma.employee.findFirst({where:{primarySiteId:x,jobTitle:"Site Manager",status:{not:"left"}}}))return t.NextResponse.json({success:!1,message:"A Site Manager already exists for this location."},{status:400});if(await a.prisma.employee.findUnique({where:{email:I}}))return t.NextResponse.json({success:!1,message:"An employee with this email already exists."},{status:400});if(await a.prisma.employee.findFirst({where:{firstName:u.trim(),lastName:g.trim(),status:{not:"left"}}}))return t.NextResponse.json({success:!1,message:`An employee named "${u.trim()} ${g.trim()}" already exists.`},{status:400});if(y&&y.trim()&&await a.prisma.employee.findFirst({where:{phone:y.trim()}}))return t.NextResponse.json({success:!1,message:"An employee with this phone number already exists."},{status:400});let $=null;if(j){let e=await (0,s.hashPassword)(S.trim()),t=await a.prisma.user.upsert({where:{email:I},update:{name:`${u.trim()} ${g.trim()}`,firstName:u.trim(),lastName:g.trim(),role:"manager",passwordHash:e,status:T||"active"},create:{name:`${u.trim()} ${g.trim()}`,firstName:u.trim(),lastName:g.trim(),email:I,username:I.split("@")[0],role:"manager",passwordHash:e,status:T||"active",avatarInitials:`${u[0]}${g[0]}`.toUpperCase()}});$=t.id,await a.prisma.location.update({where:{id:x},data:{managerId:t.id}})}let C=c?.trim();if(C?await a.prisma.employee.findUnique({where:{employeeNumber:C}})&&(C=await d()):C=await d(),!j&&A&&A.trim()&&(4!==A.trim().length||!/^\d{4}$/.test(A.trim())))return t.NextResponse.json({success:!1,message:"Employee PIN must be exactly 4 digits."},{status:400});let U=A&&A.trim()?A.trim():null,M=U?await (0,s.hashPin)(U):null,_=await a.prisma.employee.create({data:{employeeNumber:C,firstName:u.trim(),lastName:g.trim(),email:I,phone:(y||"").trim(),jobTitle:h.trim(),profileImage:b||null,primarySiteId:x,managerId:$||w||null,payType:"salaried"===R?"salaried":"hourly",hourlyRate:"hourly"===R?Number(N)||0:null,salaryAnnual:"salaried"===R?Number(E)||0:null,startDate:v,status:T||"active",pinSet:!!U,pin:U,pinHash:M},select:{id:!0,employeeNumber:!0,firstName:!0,lastName:!0,email:!0,phone:!0,jobTitle:!0,profileImage:!0,primarySiteId:!0,managerId:!0,payType:!0,hourlyRate:!0,salaryAnnual:!0,startDate:!0,status:!0,leavingDate:!0,leavingReason:!0,pinSet:!0,pin:!0,createdAt:!0,primarySite:{select:{id:!0,name:!0,town:!0}}}});if(m.faceEmbedding)try{let e="string"==typeof m.faceEmbedding?m.faceEmbedding:JSON.stringify(m.faceEmbedding);await a.prisma.$executeRawUnsafe("UPDATE `Employee` SET `faceEmbedding` = ? WHERE `id` = ?",e,_.id)}catch(e){console.error("Failed to persist faceEmbedding on Employee creation:",e)}await (0,i.logAuditEvent)({userName:p?.userName||"Admin",role:p?.role,siteId:x,entity:"Employee",action:"CREATE_EMPLOYEE",newValue:{id:_.id,employeeNumber:_.employeeNumber,name:`${_.firstName} ${_.lastName}`,jobTitle:_.jobTitle,siteId:x},reason:"Created new employee record"});try{let e=[],t="",s="",r=l.default.join(process.cwd(),"public","brand","rotabeat-logo-trimmed.png"),i=l.default.join(process.cwd(),"public","brand","rotabeat-icon-trimmed.png");if(n.default.existsSync(r)){let a=n.default.readFileSync(r);t=`data:image/png;base64,${a.toString("base64")}`,e.push({filename:"rotabeat-logo.png",path:r,cid:"rotabeat-logo",contentType:"image/png"})}if(n.default.existsSync(i)){let t=n.default.readFileSync(i);s=`data:image/png;base64,${t.toString("base64")}`,e.push({filename:"rotabeat-icon.png",path:i,cid:"rotabeat-icon",contentType:"image/png"})}let d="https://rotabeat.com",p=e.some(e=>"rotabeat-logo"===e.cid)?"cid:rotabeat-logo":t||`${d}/brand/rotabeat-logo-trimmed.png`,m=e.some(e=>"rotabeat-icon"===e.cid)?"cid:rotabeat-icon":s||`${d}/brand/rotabeat-icon-trimmed.png`,c=`${P.name}${P.town?` (${P.town})`:""}`,u=`${_.firstName} ${_.lastName}`,g=U||"Contact Manager",f=`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to RotaBeat</title>
        </head>
        <body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f1f5f9; padding: 40px 16px;">
            <tr>
              <td align="center">
                <table width="100%" border="0" cellpadding="0" cellspacing="0" style="max-width: 540px; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.08), 0 2px 4px -2px rgba(0, 0, 0, 0.05); border: 1px solid #e2e8f0;">
                  
                  <!-- Brand Top Accent Bar -->
                  <tr>
                    <td style="height: 5px; background: linear-gradient(90deg, #4F46E5 0%, #7C3AED 50%, #EC4899 100%);"></td>
                  </tr>

                  <!-- Header with Official RotaBeat Logo -->
                  <tr>
                    <td style="background-color: #ffffff; padding: 28px 24px 20px 24px; text-align: center; border-bottom: 1px solid #f1f5f9;">
                      <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                        <tr>
                          <td align="center">
                            <img src="${p}" alt="RotaBeat Logo" width="176" style="display: block; width: 176px; height: auto; border: 0; outline: none; margin: 0 auto;" />
                          </td>
                        </tr>
                      </table>
                      <p style="margin: 8px 0 0 0; color: #64748b; font-size: 13px; font-weight: 500; letter-spacing: 0.2px;">
                        Workforce &amp; Attendance Platform
                      </p>
                    </td>
                  </tr>

                  <!-- Content Area with RotaBeat Icon -->
                  <tr>
                    <td style="padding: 32px 30px;">
                      <table border="0" cellpadding="0" cellspacing="0" style="margin-bottom: 20px;">
                        <tr>
                          <td style="vertical-align: middle; padding-right: 12px;">
                            <img src="${m}" alt="RotaBeat Icon" width="34" style="display: block; width: 34px; height: auto; border: 0;" />
                          </td>
                          <td style="vertical-align: middle;">
                            <h2 style="margin: 0; color: #0f172a; font-size: 20px; font-weight: 700;">
                              Welcome to the Team!
                            </h2>
                          </td>
                        </tr>
                      </table>

                      <p style="margin: 0 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                        Hello <strong>${_.firstName}</strong>,
                      </p>
                      <p style="margin: 0 0 20px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                        You have been registered as an employee on <strong>RotaBeat</strong>. Below are your account Login credentials:
                      </p>

                      <!-- Credentials Card -->
                      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; margin: 20px 0; overflow: hidden;">
                        <tr>
                          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; width: 35%; color: #64748b; font-size: 13px; font-weight: 600;">
                            User Name :
                          </td>
                          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 700;">
                            ${u}
                          </td>
                        </tr>
                        <tr>
                          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
                            Email :
                          </td>
                          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 500;">
                            ${_.email}
                          </td>
                        </tr>
                        <tr>
                          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
                            Pin :
                          </td>
                          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0;">
                            <span style="font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, Courier, monospace; font-size: 18px; font-weight: 800; letter-spacing: 4px; color: #4F46E5; background-color: #eef2ff; border: 1px solid #c7d2fe; padding: 4px 12px; border-radius: 6px; display: inline-block;">
                              ${g}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
                            Location :
                          </td>
                          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 500;">
                            ${c}
                          </td>
                        </tr>
                        <tr>
                          <td style="padding: 12px 18px; ${j?"border-bottom: 1px solid #e2e8f0;":""} color: #64748b; font-size: 13px; font-weight: 600;">
                            Role :
                          </td>
                          <td style="padding: 12px 18px; ${j?"border-bottom: 1px solid #e2e8f0;":""} color: #0f172a; font-size: 14px; font-weight: 600;">
                            ${_.jobTitle}
                          </td>
                        </tr>
                        ${j&&S?`
                        <tr>
                          <td style="padding: 12px 18px; color: #64748b; font-size: 13px; font-weight: 600;">
                            Portal Password :
                          </td>
                          <td style="padding: 12px 18px; color: #4F46E5; font-size: 14px; font-weight: 700;">
                            ${S}
                          </td>
                        </tr>
                        `:""}
                      </table>

                      <p style="margin: 24px 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                        If you have any questions or need assistance, please contact your manager or system administrator.
                      </p>

                      <p style="margin: 0; color: #475569; font-size: 14px; line-height: 1.6;">
                        Best regards,<br /><br />
                        <strong style="color: #0f172a;">The RotaBeat Team</strong>
                      </p>
                    </td>
                  </tr>

                  <!-- Footer with Brand Icon -->
                  <tr>
                    <td style="background-color: #f8fafc; padding: 22px 24px; border-top: 1px solid #e2e8f0; text-align: center;">
                      <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto 8px auto;">
                        <tr>
                          <td style="vertical-align: middle; padding-right: 6px;">
                            <img src="${m}" alt="RotaBeat" width="18" style="display: block; width: 18px; height: auto; opacity: 0.85; border: 0;" />
                          </td>
                          <td style="vertical-align: middle;">
                            <span style="color: #475569; font-size: 12px; font-weight: 700; letter-spacing: 0.3px;">RotaBeat Platform</span>
                          </td>
                        </tr>
                      </table>
                      <p style="margin: 0; color: #94a3b8; font-size: 12px;">
                        Fast &middot; Accurate &middot; Compliant Workforce Scheduling &middot; &copy; ${new Date().getFullYear()} RotaBeat
                      </p>
                    </td>
                  </tr>

                </table>
              </td>
            </tr>
          </table>
        </body>
        </html>
      `,y=await (0,o.sendEmailNotification)({to:_.email,subject:"Welcome to RotaBeat — Your Account & Clock-In Details",html:f,attachments:e});await a.prisma.notificationAuditLog.create({data:{type:"employee_welcome",recipient:_.email,siteId:x,status:y.success?"SENT":"SIMULATED",reason:y.success?"Welcome onboarding email dispatched.":"Logged (SMTP not configured or simulation mode)."}}).catch(()=>{})}catch(e){console.error("Failed to send welcome email to employee:",e)}return t.NextResponse.json({success:!0,employee:_},{status:201})}catch(e){return console.error("POST /api/employees error:",e),t.NextResponse.json({success:!1,message:e.message||"Failed to create employee in database."},{status:500})}}async function c(e){try{let o,n=(0,r.getApiUser)(e),l=await e.json(),{id:d,firstName:p,lastName:m,email:c,phone:u,jobTitle:g,profileImage:f,primarySiteId:y,managerId:h,payType:b,hourlyRate:x,salaryAnnual:w,startDate:R,status:N,leavingDate:E,leavingReason:v,currentPassword:T,newPassword:S,pin:A}=l;if(f&&"__REMOVE__"!==f){if("string"!=typeof f||!f.startsWith("data:image/"))return t.NextResponse.json({success:!1,message:"Profile image must be a valid data URI (data:image/...)."},{status:400});if(f.length>14e5)return t.NextResponse.json({success:!1,message:"Profile image must be less than 1 MB."},{status:400})}if(!d)return t.NextResponse.json({success:!1,message:"Employee ID is required."},{status:400});let I=await a.prisma.employee.findUnique({where:{id:d}});if(!I)return t.NextResponse.json({success:!1,message:"Employee not found."},{status:404});if(n)try{(0,r.enforceSiteAccess)(n,I.primarySiteId),y&&y!==I.primarySiteId&&(0,r.enforceSiteAccess)(n,y)}catch(e){if(e instanceof Response||e&&e.status)return e}let j=c?c.trim().toLowerCase():I.email,P=(g?g.trim():I.jobTitle)==="Site Manager";if(c&&j!==I.email&&await a.prisma.employee.findUnique({where:{email:j}}))return t.NextResponse.json({success:!1,message:"Another employee with this email already exists."},{status:400});let $=p?p.trim():I.firstName,C=m?m.trim():I.lastName;if(($!==I.firstName||C!==I.lastName)&&await a.prisma.employee.findFirst({where:{firstName:$,lastName:C,id:{not:d},status:{not:"left"}}}))return t.NextResponse.json({success:!1,message:`Another employee named "${$} ${C}" already exists.`},{status:400});let U=void 0!==u?u.trim():I.phone;if(U&&U!==I.phone&&await a.prisma.employee.findFirst({where:{phone:U,id:{not:d}}}))return t.NextResponse.json({success:!1,message:"Another employee with this phone number already exists."},{status:400});if(P){let e,r=await a.prisma.user.findFirst({where:{OR:[{email:I.email},{email:j}]}});if(S&&S.trim()){if(r&&r.passwordHash&&(!T||!await (0,s.verifyPassword)(T.trim(),r.passwordHash)))return t.NextResponse.json({success:!1,message:"Current password does not match."},{status:400});e=await (0,s.hashPassword)(S.trim())}let i=await a.prisma.user.upsert({where:{email:j},update:{name:`${p?p.trim():I.firstName} ${m?m.trim():I.lastName}`,firstName:p?p.trim():I.firstName,lastName:m?m.trim():I.lastName,email:j,role:"manager",status:N||I.status,...e?{passwordHash:e}:{}},create:{name:`${p?p.trim():I.firstName} ${m?m.trim():I.lastName}`,firstName:p?p.trim():I.firstName,lastName:m?m.trim():I.lastName,email:j,username:j.split("@")[0],role:"manager",passwordHash:e||await (0,s.hashPassword)("123456"),status:N||"active"}}),o=y||I.primarySiteId;await a.prisma.location.update({where:{id:o},data:{managerId:i.id}})}if(A&&A.trim()){if(!P&&(4!==A.trim().length||!/^\d{4}$/.test(A.trim())))return t.NextResponse.json({success:!1,message:"Employee PIN must be exactly 4 digits."},{status:400});o=await (0,s.hashPin)(A.trim())}let M=await a.prisma.employee.update({where:{id:d},data:{firstName:p?p.trim():I.firstName,lastName:m?m.trim():I.lastName,email:j,phone:void 0!==u?u.trim():I.phone,jobTitle:g?g.trim():I.jobTitle,..."__REMOVE__"===f?{profileImage:null}:f?{profileImage:f}:{},primarySiteId:y||I.primarySiteId,managerId:void 0!==h?h:I.managerId,payType:b||I.payType,hourlyRate:"hourly"===(b||I.payType)?Number(x)||0:null,salaryAnnual:"salaried"===(b||I.payType)?Number(w)||0:null,startDate:R||I.startDate,status:N||I.status,leavingDate:void 0!==E?E:I.leavingDate,leavingReason:void 0!==v?v:I.leavingReason,...o?{pin:A.trim(),pinHash:o,pinSet:!0}:{}},select:{id:!0,employeeNumber:!0,firstName:!0,lastName:!0,email:!0,phone:!0,jobTitle:!0,profileImage:!0,primarySiteId:!0,managerId:!0,payType:!0,hourlyRate:!0,salaryAnnual:!0,startDate:!0,status:!0,leavingDate:!0,leavingReason:!0,pinSet:!0,pin:!0,createdAt:!0,primarySite:{select:{id:!0,name:!0,town:!0}}}});if(l.faceEmbedding)try{let e="string"==typeof l.faceEmbedding?l.faceEmbedding:JSON.stringify(l.faceEmbedding);await a.prisma.$executeRawUnsafe("UPDATE `Employee` SET `faceEmbedding` = ? WHERE `id` = ?",e,d)}catch(e){console.error("Failed to update faceEmbedding for Employee:",e)}else if("__REMOVE__"===f)try{await a.prisma.$executeRawUnsafe("UPDATE `Employee` SET `faceEmbedding` = NULL WHERE `id` = ?",d)}catch(e){}let _=!!o;return await (0,i.logAuditEvent)({userName:n?.userName||"Admin",role:n?.role,siteId:M.primarySiteId,entity:"Employee",action:_?"RESET_PIN":"UPDATE_EMPLOYEE",previousValue:{name:`${I.firstName} ${I.lastName}`,jobTitle:I.jobTitle,status:I.status},newValue:{id:M.id,name:`${M.firstName} ${M.lastName}`,jobTitle:M.jobTitle,status:M.status,pinUpdated:_},reason:_?"Employee PIN updated/reset":"Updated employee details"}),t.NextResponse.json({success:!0,employee:M})}catch(e){return console.error("PUT /api/employees error:",e),t.NextResponse.json({success:!1,message:"Failed to update employee in database."},{status:500})}}async function u(e){try{let s=(0,r.getApiUser)(e),{searchParams:o}=new URL(e.url),n=o.get("id");if(!n)return t.NextResponse.json({success:!1,message:"Employee ID is required."},{status:400});let l=await a.prisma.employee.findUnique({where:{id:n}});if(!l)return t.NextResponse.json({success:!1,message:"Employee not found."},{status:404});if(s)try{(0,r.enforceSiteAccess)(s,l.primarySiteId)}catch(e){if(e instanceof Response||e&&e.status)return e}return"Site Manager"===l.jobTitle&&(await a.prisma.location.updateMany({where:{managerId:l.managerId||void 0},data:{managerId:null}}),l.email&&await a.prisma.user.deleteMany({where:{email:l.email,role:"manager"}})),await a.prisma.employee.delete({where:{id:n}}),await (0,i.logAuditEvent)({userName:s?.userName||"Admin",role:s?.role,siteId:l.primarySiteId,entity:"Employee",action:"DELETE_EMPLOYEE",previousValue:{id:l.id,name:`${l.firstName} ${l.lastName}`,employeeNumber:l.employeeNumber,jobTitle:l.jobTitle},reason:"Employee deleted from database"}),t.NextResponse.json({success:!0,message:"Employee deleted successfully."})}catch(e){return console.error("DELETE /api/employees error:",e),t.NextResponse.json({success:!1,message:"Failed to delete employee from database."},{status:500})}}e.s(["DELETE",0,u,"GET",0,p,"POST",0,m,"PUT",0,c])},22892,e=>{"use strict";var t=e.i(47909),a=e.i(74017),s=e.i(96250),r=e.i(59756),i=e.i(61916),o=e.i(74677),n=e.i(69741),l=e.i(16795),d=e.i(87718),p=e.i(95169),m=e.i(47587),c=e.i(66012),u=e.i(70101),g=e.i(26937),f=e.i(10372),y=e.i(93695);e.i(52474);var h=e.i(220);let b=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/employees/route",pathname:"/api/employees",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/employees/route.ts",nextConfigOutput:"standalone",userland:()=>e.r(50832),...{}}),{workAsyncStorage:x,workUnitAsyncStorage:w,serverHooks:R}=b;async function N(e,t,s){s.requestMeta&&(0,r.setRequestMeta)(e,s.requestMeta),b.isDev&&(0,r.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let x="/api/employees/route";x=x.replace(/\/index$/,"")||"/";let w=await b.prepare(e,t,{srcPage:x,multiZoneDraftMode:!1});if(!w)return t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve()),null;let{buildId:R,deploymentId:N,params:E,nextConfig:v,parsedUrl:T,isDraftMode:S,prerenderManifest:A,routerServerContext:I,isOnDemandRevalidate:j,revalidateOnlyGenerated:P,resolvedPathname:$,clientReferenceManifest:C,serverActionsManifest:U}=w,M=(0,n.normalizeAppPath)(x),_=!!(A.dynamicRoutes[M]||A.routes[$]),D=async()=>((null==I?void 0:I.render404)?await I.render404(e,t,T,!1):t.end("This page could not be found"),null);if(_&&!S){let e=!!A.routes[$],t=A.dynamicRoutes[M];if(t&&!1===t.fallback&&!e){if(v.adapterPath)return await D();throw new y.NoFallbackError}}let q=null;!_||b.isDev||S||(q="/index"===(q=$)?"/":q);let O=!0===b.isDev||!_,H=_&&!O;U&&C&&(0,o.setManifestsSingleton)({page:x,clientReferenceManifest:C,serverActionsManifest:U});let F=e.method||"GET",k=(0,i.getTracer)(),L=k.getActiveScopeSpan(),B=!!(null==I?void 0:I.isWrappedByNextServer),z=!!(0,r.getRequestMeta)(e,"minimalMode"),W=(0,r.getRequestMeta)(e,"incrementalCache")||await b.getIncrementalCache(e,v,A,z);null==W||W.resetRequestCache(),globalThis.__incrementalCache=W;let V={params:E,previewProps:A.preview,renderOpts:{experimental:{authInterrupts:!!v.experimental.authInterrupts,useCacheTimeout:v.experimental.useCacheTimeout},cacheComponents:!!v.cacheComponents,validationLevel:v.experimental.instantInsights.validationLevel,supportsDynamicResponse:O,incrementalCache:W,hmrRefreshHash:(0,r.getRequestMeta)(e,"hmrRefreshHash"),cacheLifeProfiles:v.cacheLife,staticPageGenerationTimeout:v.staticPageGenerationTimeout,waitUntil:s.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,s,r)=>b.onRequestError(e,t,s,r,I)},sharedContext:{buildId:R,deploymentId:N}},K=new l.NodeNextRequest(e),G=new l.NodeNextResponse(t),Y=d.NextRequestAdapter.fromNodeNextRequest(K,(0,d.signalFromNodeResponse)(t)),J=async({previousCacheEntry:a})=>{try{if(!z&&j&&P&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let r=await b.handle(Y,V);e.fetchMetrics=V.renderOpts.fetchMetrics;let i=V.renderOpts.pendingWaitUntil;i&&s.waitUntil&&(s.waitUntil(i),i=void 0);let o=V.renderOpts.collectedTags;if(!_)return await (0,c.sendResponse)(K,G,r,i),null;{let e=await r.blob(),t=(0,u.toNodeOutgoingHttpHeaders)(r.headers);o&&(t[f.NEXT_CACHE_TAGS_HEADER]=o),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==V.renderOpts.collectedRevalidate&&!(V.renderOpts.collectedRevalidate>=f.INFINITE_CACHE)&&V.renderOpts.collectedRevalidate,s=void 0===V.renderOpts.collectedExpire||V.renderOpts.collectedExpire>=f.INFINITE_CACHE?!1!==a&&a>0?v.expireTime:void 0:V.renderOpts.collectedExpire;return{value:{kind:h.CachedRouteKind.APP_ROUTE,status:r.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:s}}}}catch(t){throw(null==a?void 0:a.isStale)&&await b.onRequestError(e,t,{routerKind:"App Router",routePath:x,routeType:"route",revalidateReason:(0,m.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:j})},!1,I),t}},X=async(r,o)=>{try{var n,l;let r=await b.handleResponse({req:e,nextConfig:v,cacheKey:q,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:A,isRoutePPREnabled:!1,isOnDemandRevalidate:j,revalidateOnlyGenerated:P,responseGenerator:J,waitUntil:s.waitUntil,isMinimalMode:z});if(!_)return;if((null==r||null==(n=r.value)?void 0:n.kind)!==h.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==r||null==(l=r.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});z||t.setHeader("x-nextjs-cache",j?"REVALIDATED":r.isMiss?"MISS":r.isStale?"STALE":"HIT"),S&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let i=(0,u.fromNodeOutgoingHttpHeaders)(r.value.headers);z&&_||i.delete(f.NEXT_CACHE_TAGS_HEADER),!r.cacheControl||t.getHeader("Cache-Control")||i.get("Cache-Control")||i.set("Cache-Control",(0,g.getCacheControlHeader)(r.cacheControl)),await (0,c.sendResponse)(K,G,new Response(r.value.body,{headers:i,status:r.value.status||200}));return}catch(t){if(t instanceof y.NoFallbackError||await b.onRequestError(e,t,{routerKind:"App Router",routePath:M,routeType:"route",revalidateReason:(0,m.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:j})},!1,I),_)throw t;await (0,c.sendResponse)(K,G,new Response(null,{status:500}));return}finally{(()=>{if(!r)return;let e=t.statusCode;r.setAttributes({"http.status_code":e,"next.rsc":!1}),e&&e>=500&&(r.setStatus({code:i.SpanStatusCode.ERROR}),r.setAttribute("error.type",e.toString()));let a=k.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==p.BaseServerSpan.handleRequest)return console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=a.get("next.route")||M,n=`${F} ${s}`;r.setAttributes({"next.route":s,"http.route":s,"next.span_name":n}),r.updateName(n),o&&o!==r&&(o.setAttribute("http.route",s),o.updateName(n))})()}};if(B&&L)await X(L,void 0);else{let t=k.getActiveScopeSpan();await k.withPropagatedContext(e.headers,()=>k.trace(p.BaseServerSpan.handleRequest,{spanName:`${F} ${x}`,kind:i.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},e=>X(e,t)),void 0,!B)}}e.s(["handler",0,N,"patchFetch",0,function(){return(0,s.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:w})},"routeModule",0,b,"serverHooks",0,R,"workAsyncStorage",0,x,"workUnitAsyncStorage",0,w])}];

//# sourceMappingURL=_1rd-t9d._.js.map