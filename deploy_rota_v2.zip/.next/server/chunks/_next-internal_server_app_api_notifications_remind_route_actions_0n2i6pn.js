module.exports=[37657,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_notifications_remind_route_actions_0n2i6pn.js.map