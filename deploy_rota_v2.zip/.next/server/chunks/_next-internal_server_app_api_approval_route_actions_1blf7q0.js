module.exports=[86126,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_approval_route_actions_1blf7q0.js.map