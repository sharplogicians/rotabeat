module.exports=[8984,e=>{"use strict";var t=e.i(89171),a=e.i(15270),r=e.i(22734),o=e.i(14747),i=e.i(53905),n=e.i(35487),s=e.i(7607);async function l(e,t){let l={totalEmployees:0,sentCount:0,details:[]};try{let d=await a.prisma.location.findUnique({where:{id:e}});if(!d)return console.warn(`[sendRotaPublishedEmails] Site not found: ${e}`),l;let p=(0,n.weekDays)(t);if(!p||7!==p.length)return console.warn(`[sendRotaPublishedEmails] Invalid weekStart: ${t}`),l;let c=p[0],u=p[6],f=await a.prisma.shift.findMany({where:{siteId:e,date:{gte:c,lte:u}},include:{employee:!0},orderBy:[{date:"asc"},{startTime:"asc"}]}),g=new Map;for(let e of f)e.employee&&"active"===e.employee.status&&e.employee.email&&e.employee.email.includes("@")&&!g.has(e.employeeId)&&g.set(e.employeeId,e.employee);if(l.totalEmployees=g.size,0===l.totalEmployees)return l;let h=o.default.join(process.cwd(),"public","brand","rotabeat-logo-trimmed.png"),x=o.default.join(process.cwd(),"public","brand","rotabeat-icon-trimmed.png"),m=[],b="",y="";if(r.default.existsSync(h)){let e=r.default.readFileSync(h);b=`data:image/png;base64,${e.toString("base64")}`,m.push({filename:"rotabeat-logo.png",path:h,cid:"rotabeat-logo",contentType:"image/png"})}if(r.default.existsSync(x)){let e=r.default.readFileSync(x);y=`data:image/png;base64,${e.toString("base64")}`,m.push({filename:"rotabeat-icon.png",path:x,cid:"rotabeat-icon",contentType:"image/png"})}let w="https://rotabeat.com",R=m.some(e=>"rotabeat-logo"===e.cid)?"cid:rotabeat-logo":b||`${w}/brand/rotabeat-logo-trimmed.png`,v=m.some(e=>"rotabeat-icon"===e.cid)?"cid:rotabeat-icon":y||`${w}/brand/rotabeat-icon-trimmed.png`,E=`${d.name}${d.town?` (${d.town})`:""}`,k=(0,n.formatWeekRange)(t);for(let r of g.values())try{let o=f.filter(e=>e.employeeId===r.id);if(0===o.length)continue;let d=0;for(let e of o)d+=(0,s.scheduledMinutes)(e);let c=(d/60).toFixed(1),u=o.length,g=0,h=p.map(e=>{let t=(0,n.formatDayMonth)(e),a=o.filter(t=>t.date===e);return a.length>0?a.map(e=>`
                <tr style="border-bottom: 1px solid #e2e8f0;">
                  <td style="padding: 12px 14px; font-weight: 600; color: #0f172a; font-size: 13px; white-space: nowrap;">
                    ${t}
                  </td>
                  <td style="padding: 12px 14px; white-space: nowrap;">
                    <span style="display: inline-block; background-color: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 13px;">
                      ${e.startTime} – ${e.endTime}
                    </span>
                  </td>
                  <td style="padding: 12px 14px; color: #334155; font-size: 13px; font-weight: 500;">
                    ${e.role||r.jobTitle||"Team Member"}
                  </td>
                  <td style="padding: 12px 14px; color: #64748b; font-size: 12px;">
                    ${e.unpaidBreakMinutes?`${e.unpaidBreakMinutes}m break`:"No break"}
                  </td>
                </tr>
              `).join(""):(g++,`
                <tr style="border-bottom: 1px solid #e2e8f0; background-color: #f8fafc;">
                  <td style="padding: 12px 14px; font-weight: 500; color: #64748b; font-size: 13px; white-space: nowrap;">
                    ${t}
                  </td>
                  <td style="padding: 12px 14px; white-space: nowrap;">
                    <span style="display: inline-block; background-color: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 12px; letter-spacing: 0.5px;">
                      OFF
                    </span>
                  </td>
                  <td style="padding: 12px 14px; color: #94a3b8; font-size: 13px;">
                    —
                  </td>
                  <td style="padding: 12px 14px; color: #94a3b8; font-size: 12px; font-style: italic;">
                    Rest Day
                  </td>
                </tr>
              `)}).join(""),x=`
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Your Schedule — RotaBeat</title>
          </head>
          <body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f1f5f9; padding: 40px 16px;">
              <tr>
                <td align="center">
                  <table width="100%" border="0" cellpadding="0" cellspacing="0" style="max-width: 600px; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.08), 0 2px 4px -2px rgba(0, 0, 0, 0.05); border: 1px solid #e2e8f0;">
                    
                    <!-- Brand Top Accent Bar -->
                    <tr>
                      <td style="height: 5px; background: linear-gradient(90deg, #4F46E5 0%, #7C3AED 50%, #EC4899 100%);"></td>
                    </tr>

                    <!-- Header with Official RotaBeat Logo -->
                    <tr>
                      <td style="background-color: #ffffff; padding: 28px 24px 20px 24px; text-align: center; border-bottom: 1px solid #f1f5f9;">
                        <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                          <tr>
                            <td align="center">
                              <img src="${R}" alt="RotaBeat Logo" width="176" style="display: block; width: 176px; height: auto; border: 0; outline: none; margin: 0 auto;" />
                            </td>
                          </tr>
                        </table>
                        <p style="margin: 8px 0 0 0; color: #64748b; font-size: 13px; font-weight: 500; letter-spacing: 0.2px;">
                          Workforce &amp; Attendance Platform
                        </p>
                      </td>
                    </tr>

                    <!-- Content Area -->
                    <tr>
                      <td style="padding: 32px 30px;">
                        <table border="0" cellpadding="0" cellspacing="0" style="margin-bottom: 20px;">
                          <tr>
                            <td style="vertical-align: middle; padding-right: 12px;">
                              <img src="${v}" alt="RotaBeat Icon" width="34" style="display: block; width: 34px; height: auto; border: 0;" />
                            </td>
                            <td style="vertical-align: middle;">
                              <h2 style="margin: 0; color: #0f172a; font-size: 20px; font-weight: 700;">
                                Your Weekly Work Schedule
                              </h2>
                            </td>
                          </tr>
                        </table>

                        <p style="margin: 0 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                          Hello <strong>${r.firstName}</strong>,
                        </p>
                        <p style="margin: 0 0 20px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                          The rota for <strong>${E}</strong> for the week of <strong>${k}</strong> has been published. Below are your scheduled shifts and off days:
                        </p>

                        <!-- Summary Cards -->
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin: 0 0 24px 0;">
                          <tr>
                            <td style="width: 32%; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; text-align: center;">
                              <div style="font-size: 11px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Shifts</div>
                              <div style="font-size: 18px; font-weight: 700; color: #4F46E5; margin-top: 4px;">${u}</div>
                            </td>
                            <td style="width: 2%;"></td>
                            <td style="width: 32%; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; text-align: center;">
                              <div style="font-size: 11px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Off Days</div>
                              <div style="font-size: 18px; font-weight: 700; color: #0f172a; margin-top: 4px;">${g}</div>
                            </td>
                            <td style="width: 2%;"></td>
                            <td style="width: 32%; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; text-align: center;">
                              <div style="font-size: 11px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Total Hours</div>
                              <div style="font-size: 18px; font-weight: 700; color: #0f172a; margin-top: 4px;">${c} hrs</div>
                            </td>
                          </tr>
                        </table>

                        <!-- Schedule Table -->
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border: 1px solid #e2e8f0; border-radius: 10px; overflow: hidden; border-collapse: separate; border-spacing: 0;">
                          <thead>
                            <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                              <th align="left" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.5px;">Day &amp; Date</th>
                              <th align="left" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.5px;">Shift</th>
                              <th align="left" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.5px;">Role</th>
                              <th align="left" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.5px;">Break</th>
                            </tr>
                          </thead>
                          <tbody>
                            ${h}
                          </tbody>
                        </table>

                        <p style="margin: 28px 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                          If you have any questions or need to request a shift swap, please contact your manager or system administrator.
                        </p>

                        <p style="margin: 0; color: #475569; font-size: 14px; line-height: 1.6;">
                          Best regards,<br /><br />
                          <strong style="color: #0f172a;">The RotaBeat Team</strong>
                        </p>
                      </td>
                    </tr>

                    <!-- Footer with Brand Icon -->
                    <tr>
                      <td style="background-color: #f8fafc; padding: 22px 24px; border-top: 1px solid #e2e8f0; text-align: center;">
                        <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto 8px auto;">
                          <tr>
                            <td style="vertical-align: middle; padding-right: 6px;">
                              <img src="${v}" alt="RotaBeat" width="18" style="display: block; width: 18px; height: auto; opacity: 0.85; border: 0;" />
                            </td>
                            <td style="vertical-align: middle;">
                              <span style="color: #475569; font-size: 12px; font-weight: 700; letter-spacing: 0.3px;">RotaBeat Platform</span>
                            </td>
                          </tr>
                        </table>
                        <p style="margin: 0; color: #94a3b8; font-size: 12px;">
                          Fast &middot; Accurate &middot; Compliant Workforce Scheduling &middot; &copy; ${new Date().getFullYear()} RotaBeat
                        </p>
                      </td>
                    </tr>

                  </table>
                </td>
              </tr>
            </table>
          </body>
          </html>
        `,b=await (0,i.sendEmailNotification)({to:r.email,subject:`Your Work Schedule: Week of ${k} — RotaBeat`,html:x,attachments:m});b.success&&l.sentCount++,l.details.push({employeeId:r.id,email:r.email,success:b.success}),await a.prisma.notificationAuditLog.create({data:{type:"rota_published",recipient:r.email,siteId:e,weekStart:t,status:b.success?"SENT":"SIMULATED",reason:`Rota published for week ${k}. ${u} shift(s), ${g} off day(s), ${c} hrs scheduled.`}}).catch(()=>{})}catch(e){console.error(`Failed to send rota email to ${r.email}:`,e),l.details.push({employeeId:r.id,email:r.email,success:!1})}}catch(e){console.error("sendRotaPublishedEmails error:",e)}return l}async function d(e){try{let{searchParams:r}=new URL(e.url),o=r.get("siteId"),i=r.get("weekStart");if(!o||!i)return t.NextResponse.json({success:!1,message:"siteId and weekStart are required."},{status:400});let n=await a.prisma.rota.findUnique({where:{siteId_weekStart:{siteId:o,weekStart:i}}});return n||(n=await a.prisma.rota.create({data:{siteId:o,weekStart:i,status:"draft"}})),t.NextResponse.json({success:!0,rota:n})}catch(e){return console.error("GET /api/rota error:",e),t.NextResponse.json({success:!1,message:"Failed to fetch rota details."},{status:500})}}async function p(e){try{let{siteId:r,weekStart:o,status:i,createdBy:n}=await e.json();if(!r||!o||!i)return t.NextResponse.json({success:!1,message:"siteId, weekStart, and status are required."},{status:400});let s={status:i};"published"===i?s.publishedAt=new Date:"locked"===i&&(s.lockedAt=new Date);let d=await a.prisma.rota.upsert({where:{siteId_weekStart:{siteId:r,weekStart:o}},update:s,create:{siteId:r,weekStart:o,status:i,createdBy:n,..."published"===i?{publishedAt:new Date}:{},..."locked"===i?{lockedAt:new Date}:{}}});if("published"===i)try{await l(r,o)}catch(e){console.error("Non-blocking error dispatching rota publish emails:",e)}return t.NextResponse.json({success:!0,rota:d})}catch(e){return console.error("POST /api/rota error:",e),t.NextResponse.json({success:!1,message:e.message||"Failed to update rota status."},{status:500})}}e.s(["GET",0,d,"POST",0,p],8984)},97285,e=>{"use strict";var t=e.i(47909),a=e.i(74017),r=e.i(96250),o=e.i(59756),i=e.i(61916),n=e.i(74677),s=e.i(69741),l=e.i(16795),d=e.i(87718),p=e.i(95169),c=e.i(47587),u=e.i(66012),f=e.i(70101),g=e.i(26937),h=e.i(10372),x=e.i(93695);e.i(52474);var m=e.i(220);let b=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/rota/route",pathname:"/api/rota",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/rota/route.ts",nextConfigOutput:"standalone",userland:()=>e.r(8984),...{}}),{workAsyncStorage:y,workUnitAsyncStorage:w,serverHooks:R}=b;async function v(e,t,r){r.requestMeta&&(0,o.setRequestMeta)(e,r.requestMeta),b.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let y="/api/rota/route";y=y.replace(/\/index$/,"")||"/";let w=await b.prepare(e,t,{srcPage:y,multiZoneDraftMode:!1});if(!w)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:R,deploymentId:v,params:E,nextConfig:k,parsedUrl:S,isDraftMode:T,prerenderManifest:C,routerServerContext:A,isOnDemandRevalidate:$,revalidateOnlyGenerated:N,resolvedPathname:P,clientReferenceManifest:I,serverActionsManifest:z}=w,D=(0,s.normalizeAppPath)(y),O=!!(C.dynamicRoutes[D]||C.routes[P]),q=async()=>((null==A?void 0:A.render404)?await A.render404(e,t,S,!1):t.end("This page could not be found"),null);if(O&&!T){let e=!!C.routes[P],t=C.dynamicRoutes[D];if(t&&!1===t.fallback&&!e){if(k.adapterPath)return await q();throw new x.NoFallbackError}}let B=null;!O||b.isDev||T||(B="/index"===(B=P)?"/":B);let M=!0===b.isDev||!O,_=O&&!M;z&&I&&(0,n.setManifestsSingleton)({page:y,clientReferenceManifest:I,serverActionsManifest:z});let H=e.method||"GET",F=(0,i.getTracer)(),j=F.getActiveScopeSpan(),U=!!(null==A?void 0:A.isWrappedByNextServer),L=!!(0,o.getRequestMeta)(e,"minimalMode"),W=(0,o.getRequestMeta)(e,"incrementalCache")||await b.getIncrementalCache(e,k,C,L);null==W||W.resetRequestCache(),globalThis.__incrementalCache=W;let K={params:E,previewProps:C.preview,renderOpts:{experimental:{authInterrupts:!!k.experimental.authInterrupts,useCacheTimeout:k.experimental.useCacheTimeout},cacheComponents:!!k.cacheComponents,validationLevel:k.experimental.instantInsights.validationLevel,supportsDynamicResponse:M,incrementalCache:W,hmrRefreshHash:(0,o.getRequestMeta)(e,"hmrRefreshHash"),cacheLifeProfiles:k.cacheLife,staticPageGenerationTimeout:k.staticPageGenerationTimeout,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,o)=>b.onRequestError(e,t,r,o,A)},sharedContext:{buildId:R,deploymentId:v}},G=new l.NodeNextRequest(e),Y=new l.NodeNextResponse(t),V=d.NextRequestAdapter.fromNodeNextRequest(G,(0,d.signalFromNodeResponse)(t)),X=async({previousCacheEntry:a})=>{try{if(!L&&$&&N&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await b.handle(V,K);e.fetchMetrics=K.renderOpts.fetchMetrics;let i=K.renderOpts.pendingWaitUntil;i&&r.waitUntil&&(r.waitUntil(i),i=void 0);let n=K.renderOpts.collectedTags;if(!O)return await (0,u.sendResponse)(G,Y,o,i),null;{let e=await o.blob(),t=(0,f.toNodeOutgoingHttpHeaders)(o.headers);n&&(t[h.NEXT_CACHE_TAGS_HEADER]=n),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=h.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,r=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=h.INFINITE_CACHE?!1!==a&&a>0?k.expireTime:void 0:K.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await b.onRequestError(e,t,{routerKind:"App Router",routePath:y,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:_,isOnDemandRevalidate:$})},!1,A),t}},Z=async(o,n)=>{try{var s,l;let o=await b.handleResponse({req:e,nextConfig:k,cacheKey:B,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:C,isRoutePPREnabled:!1,isOnDemandRevalidate:$,revalidateOnlyGenerated:N,responseGenerator:X,waitUntil:r.waitUntil,isMinimalMode:L});if(!O)return;if((null==o||null==(s=o.value)?void 0:s.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==o||null==(l=o.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});L||t.setHeader("x-nextjs-cache",$?"REVALIDATED":o.isMiss?"MISS":o.isStale?"STALE":"HIT"),T&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let i=(0,f.fromNodeOutgoingHttpHeaders)(o.value.headers);L&&O||i.delete(h.NEXT_CACHE_TAGS_HEADER),!o.cacheControl||t.getHeader("Cache-Control")||i.get("Cache-Control")||i.set("Cache-Control",(0,g.getCacheControlHeader)(o.cacheControl)),await (0,u.sendResponse)(G,Y,new Response(o.value.body,{headers:i,status:o.value.status||200}));return}catch(t){if(t instanceof x.NoFallbackError||await b.onRequestError(e,t,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:_,isOnDemandRevalidate:$})},!1,A),O)throw t;await (0,u.sendResponse)(G,Y,new Response(null,{status:500}));return}finally{(()=>{if(!o)return;let e=t.statusCode;o.setAttributes({"http.status_code":e,"next.rsc":!1}),e&&e>=500&&(o.setStatus({code:i.SpanStatusCode.ERROR}),o.setAttribute("error.type",e.toString()));let a=F.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==p.BaseServerSpan.handleRequest)return console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route")||D,s=`${H} ${r}`;o.setAttributes({"next.route":r,"http.route":r,"next.span_name":s}),o.updateName(s),n&&n!==o&&(n.setAttribute("http.route",r),n.updateName(s))})()}};if(U&&j)await Z(j,void 0);else{let t=F.getActiveScopeSpan();await F.withPropagatedContext(e.headers,()=>F.trace(p.BaseServerSpan.handleRequest,{spanName:`${H} ${y}`,kind:i.SpanKind.SERVER,attributes:{"http.method":H,"http.target":e.url}},e=>Z(e,t)),void 0,!U)}}e.s(["handler",0,v,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:w})},"routeModule",0,b,"serverHooks",0,R,"workAsyncStorage",0,y,"workUnitAsyncStorage",0,w])}];

//# sourceMappingURL=_0jkyil5._.js.map