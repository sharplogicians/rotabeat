module.exports=[20102,e=>{"use strict";var t=e.i(22734),o=e.i(14747),i=e.i(15270),r=e.i(53905),a=e.i(35487),d=e.i(7607);function n(){let e=o.default.join(process.cwd(),"public","brand","rotabeat-logo-trimmed.png"),i=o.default.join(process.cwd(),"public","brand","rotabeat-icon-trimmed.png"),r=[],a="",d="";if(t.default.existsSync(e)){let o=t.default.readFileSync(e);a=`data:image/png;base64,${o.toString("base64")}`,r.push({filename:"rotabeat-logo.png",path:e,cid:"rotabeat-logo",contentType:"image/png"})}if(t.default.existsSync(i)){let e=t.default.readFileSync(i);d=`data:image/png;base64,${e.toString("base64")}`,r.push({filename:"rotabeat-icon.png",path:i,cid:"rotabeat-icon",contentType:"image/png"})}let n="https://rotabeat.com",l=r.some(e=>"rotabeat-logo"===e.cid)?"cid:rotabeat-logo":a||`${n}/brand/rotabeat-logo-trimmed.png`,s=r.some(e=>"rotabeat-icon"===e.cid)?"cid:rotabeat-icon":d||`${n}/brand/rotabeat-icon-trimmed.png`;return{attachments:r,logoSrc:l,iconSrc:s,appBase:n}}function l(e){let{attachments:t,logoSrc:o,iconSrc:i}=n();return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${e.title} — RotaBeat</title>
    </head>
    <body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f1f5f9; padding: 40px 16px;">
        <tr>
          <td align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" style="max-width: 580px; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.08), 0 2px 4px -2px rgba(0, 0, 0, 0.05); border: 1px solid #e2e8f0;">
              
              <!-- Brand Top Accent Bar -->
              <tr>
                <td style="height: 5px; background: linear-gradient(90deg, #4F46E5 0%, #7C3AED 50%, #EC4899 100%);"></td>
              </tr>

              <!-- Header with Official RotaBeat Logo -->
              <tr>
                <td style="background-color: #ffffff; padding: 26px 24px 18px 24px; text-align: center; border-bottom: 1px solid #f1f5f9;">
                  <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                    <tr>
                      <td align="center">
                        <img src="${o}" alt="RotaBeat Logo" width="176" style="display: block; width: 176px; height: auto; border: 0; outline: none; margin: 0 auto;" />
                      </td>
                    </tr>
                  </table>
                  <p style="margin: 8px 0 0 0; color: #64748b; font-size: 13px; font-weight: 500; letter-spacing: 0.2px;">
                    Workforce &amp; Attendance Platform
                  </p>
                </td>
              </tr>

              <!-- Content Area -->
              <tr>
                <td style="padding: 30px 28px;">
                  <table border="0" cellpadding="0" cellspacing="0" style="margin-bottom: 20px;">
                    <tr>
                      <td style="vertical-align: middle; padding-right: 12px;">
                        <img src="${i}" alt="RotaBeat Icon" width="32" style="display: block; width: 32px; height: auto; border: 0;" />
                      </td>
                      <td style="vertical-align: middle;">
                        <h2 style="margin: 0; color: #0f172a; font-size: 20px; font-weight: 700; line-height: 1.3;">
                          ${e.title}
                        </h2>
                      </td>
                    </tr>
                  </table>

                  ${e.bodyHtml}

                  <p style="margin: 28px 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
                    If you have any questions or need assistance, please contact your manager or system administrator.
                  </p>

                  <p style="margin: 0; color: #475569; font-size: 14px; line-height: 1.6;">
                    Best regards,<br /><br />
                    <strong style="color: #0f172a;">The RotaBeat Team</strong>
                  </p>
                </td>
              </tr>

              <!-- Footer with Brand Icon -->
              <tr>
                <td style="background-color: #f8fafc; padding: 20px 24px; border-top: 1px solid #e2e8f0; text-align: center;">
                  <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto 8px auto;">
                    <tr>
                      <td style="vertical-align: middle; padding-right: 6px;">
                        <img src="${i}" alt="RotaBeat" width="18" style="display: block; width: 18px; height: auto; opacity: 0.85; border: 0;" />
                      </td>
                      <td style="vertical-align: middle;">
                        <span style="color: #475569; font-size: 12px; font-weight: 700; letter-spacing: 0.3px;">RotaBeat Platform</span>
                      </td>
                    </tr>
                  </table>
                  <p style="margin: 0; color: #94a3b8; font-size: 12px;">
                    Fast &middot; Accurate &middot; Compliant Workforce Scheduling &middot; &copy; ${new Date().getFullYear()} RotaBeat
                  </p>
                </td>
              </tr>

            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>
  `}async function s(){let e=0;try{let t=(0,a.getTodayIso)(),o=(0,a.addDays)(t,1),d=await i.prisma.shift.findMany({where:{date:o},include:{employee:!0,site:!0},orderBy:{startTime:"asc"}}),{attachments:s}=n();for(let t of d){if(!t.employee||"active"!==t.employee.status||!t.employee.email||!t.employee.email.includes("@")||await i.prisma.notificationAuditLog.findFirst({where:{type:"upcoming_shift_reminder",recipient:t.employee.email,reason:{contains:t.id}}}))continue;let o=`${t.site?.name||"Location"}${t.site?.town?` (${t.site.town})`:""}`,d=(0,a.formatDateLong)(t.date),n=t.employee.firstName,p=`
        <p style="margin: 0 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
          Hello <strong>${n}</strong>,
        </p>
        <p style="margin: 0 0 20px 0; color: #475569; font-size: 14px; line-height: 1.6;">
          This is a friendly reminder of your upcoming scheduled shift tomorrow at <strong>${o}</strong>.
        </p>

        <!-- Shift Details Card -->
        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; margin: 20px 0; overflow: hidden;">
          <tr>
            <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; width: 35%; color: #64748b; font-size: 13px; font-weight: 600;">
              Date :
            </td>
            <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 700;">
              ${d}
            </td>
          </tr>
          <tr>
            <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
              Shift Time :
            </td>
            <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0;">
              <span style="display: inline-block; background-color: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 14px;">
                ${t.startTime} – ${t.endTime}
              </span>
            </td>
          </tr>
          <tr>
            <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
              Role :
            </td>
            <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 600;">
              ${t.role||t.employee.jobTitle||"Team Member"}
            </td>
          </tr>
          <tr>
            <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
              Location :
            </td>
            <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 500;">
              ${o}
            </td>
          </tr>
          <tr>
            <td style="padding: 12px 18px; color: #64748b; font-size: 13px; font-weight: 600;">
              Break :
            </td>
            <td style="padding: 12px 18px; color: #0f172a; font-size: 14px; font-weight: 500;">
              ${t.unpaidBreakMinutes?`${t.unpaidBreakMinutes} mins unpaid break`:"No break"}
            </td>
          </tr>
        </table>

        <!-- Friendly Reminder Notice -->
        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; margin: 16px 0;">
          <tr>
            <td style="padding: 14px 16px; color: #1e40af; font-size: 13px; line-height: 1.5;">
              <strong>Clock-In Reminder:</strong> Please aim to arrive 5–10 minutes before your shift starts and clock in at the tablet kiosk using your 4-digit PIN or Face Match.
            </td>
          </tr>
        </table>
      `,c=l({title:"Upcoming Shift Reminder",bodyHtml:p}),f=await (0,r.sendEmailNotification)({to:t.employee.email,subject:`Upcoming Shift Reminder: Tomorrow (${t.startTime} – ${t.endTime}) — RotaBeat`,html:c,attachments:s});f.success&&e++,await i.prisma.notificationAuditLog.create({data:{type:"upcoming_shift_reminder",recipient:t.employee.email,siteId:t.siteId,status:f.success?"SENT":"SIMULATED",reason:`Upcoming shift reminder for ${t.date} (${t.startTime}-${t.endTime}). Shift ID: ${t.id}`}}).catch(()=>{})}}catch(e){console.error("sendUpcomingShiftReminders error:",e)}return{sentCount:e}}async function p(e){let t=0,{shiftId:o,employeeName:a,siteId:d,siteName:s,scheduledStartTime:p,role:c,lateMinutes:f}=e;try{if(await i.prisma.notificationAuditLog.findFirst({where:{type:"missed_clock_in_alert",siteId:d,reason:{contains:o}}}))return{sentCount:0};let e=new Set,g=await i.prisma.location.findUnique({where:{id:d}});if(g?.managerId){let t=await i.prisma.user.findUnique({where:{id:g.managerId}});t?.email&&t.email.includes("@")&&e.add(t.email)}for(let t of(await i.prisma.employee.findMany({where:{primarySiteId:d,jobTitle:"Site Manager",status:"active"}})))t.email&&t.email.includes("@")&&e.add(t.email);for(let t of(await i.prisma.user.findMany({where:{role:{in:["business_owner","head_office"]},status:"active"}})))t.email&&t.email.includes("@")&&e.add(t.email);if(0===e.size)return{sentCount:0};let{attachments:m,appBase:x}=n(),b=`
      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; margin: 0 0 20px 0;">
        <tr>
          <td style="padding: 14px 16px; color: #991b1b; font-size: 13px; font-weight: 600; line-height: 1.5;">
            ⚠️ URGENT ATTENDANCE ALERT: Employee is 5+ minutes overdue without clocking in.
          </td>
        </tr>
      </table>

      <p style="margin: 0 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
        <strong>${a}</strong> was scheduled to begin their shift at <strong>${p}</strong> at <strong>${s}</strong>, but has not clocked in on the attendance kiosk.
      </p>

      <!-- Incident Details Card -->
      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; margin: 20px 0; overflow: hidden;">
        <tr>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; width: 35%; color: #64748b; font-size: 13px; font-weight: 600;">
            Employee :
          </td>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 700;">
            ${a}
          </td>
        </tr>
        <tr>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
            Scheduled Start :
          </td>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 600;">
            ${p}
          </td>
        </tr>
        <tr>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
            Time Overdue :
          </td>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0;">
            <span style="display: inline-block; background-color: #fee2e2; color: #b91c1c; border: 1px solid #fca5a5; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 13px;">
              ${f} minutes late (No punch recorded)
            </span>
          </td>
        </tr>
        <tr>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
            Location :
          </td>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 500;">
            ${s}
          </td>
        </tr>
        <tr>
          <td style="padding: 12px 18px; color: #64748b; font-size: 13px; font-weight: 600;">
            Role :
          </td>
          <td style="padding: 12px 18px; color: #0f172a; font-size: 14px; font-weight: 500;">
            ${c||"Scheduled Staff"}
          </td>
        </tr>
      </table>

      <!-- Action Button -->
      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin: 24px 0 10px 0;">
        <tr>
          <td align="center">
            <a href="${x}/attendance" style="display: inline-block; background-color: #dc2626; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 700; font-size: 14px;">
              View Live Attendance &amp; Arrange Cover &rarr;
            </a>
          </td>
        </tr>
      </table>
    `,h=l({title:"Missed Clock-In / No-Show Alert",bodyHtml:b});for(let n of e){let e=await (0,r.sendEmailNotification)({to:n,subject:`⚠️ Urgent: Missed Clock-In — ${a} at ${s} (${f}m overdue)`,html:h,attachments:m});e.success&&t++,await i.prisma.notificationAuditLog.create({data:{type:"missed_clock_in_alert",recipient:n,siteId:d,status:e.success?"SENT":"SIMULATED",reason:`Missed clock-in alert for ${a} (${p}). ${f} mins late. Shift ID: ${o}`}}).catch(()=>{})}}catch(e){console.error("sendMissedClockInAlert error:",e)}return{sentCount:t}}async function c(e){let t=0,{siteId:o,weekStart:s}=e;try{let e=await i.prisma.orgSettings.findFirst();if(e&&!e.weeklyApprovalEmailReminder||await i.prisma.notificationAuditLog.findFirst({where:{siteId:o,weekStart:s,type:"weekly_approval_reminder"}}))return{sentCount:0};let p=await i.prisma.location.findUnique({where:{id:o}});if(!p)return{sentCount:0};let c=`${p.name}${p.town?` (${p.town})`:""}`,f=(0,a.formatWeekRange)(s),g=(0,a.weekDays)(s),m=g[0],x=g[6],b=await i.prisma.shift.findMany({where:{siteId:o,date:{gte:m,lte:x}}}),h=new Set(b.map(e=>e.employeeId)).size,y=0;for(let e of b)y+=(0,d.scheduledMinutes)(e);let u=(y/60).toFixed(1),w=new Set;if(p.managerId){let e=await i.prisma.user.findUnique({where:{id:p.managerId}});e?.email&&e.email.includes("@")&&w.add(e.email)}for(let e of(await i.prisma.employee.findMany({where:{primarySiteId:o,jobTitle:"Site Manager",status:"active"}})))e.email&&e.email.includes("@")&&w.add(e.email);if(0===w.size)for(let e of(await i.prisma.user.findMany({where:{role:{in:["business_owner","head_office"]},status:"active"}})))e.email&&e.email.includes("@")&&w.add(e.email);if(0===w.size)return{sentCount:0};let{attachments:k,appBase:$}=n(),z=`
      <p style="margin: 0 0 16px 0; color: #475569; font-size: 14px; line-height: 1.6;">
        This is a notification that weekly staff timesheets for <strong>${c}</strong> are ready for review and sign-off.
      </p>

      <!-- Timesheet Summary Card -->
      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; margin: 20px 0; overflow: hidden;">
        <tr>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; width: 35%; color: #64748b; font-size: 13px; font-weight: 600;">
            Location :
          </td>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 700;">
            ${c}
          </td>
        </tr>
        <tr>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
            Week Period :
          </td>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #0f172a; font-size: 14px; font-weight: 600;">
            ${f}
          </td>
        </tr>
        <tr>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #64748b; font-size: 13px; font-weight: 600;">
            Staff on Shift :
          </td>
          <td style="padding: 12px 18px; border-bottom: 1px solid #e2e8f0; color: #4338ca; font-size: 14px; font-weight: 700;">
            ${h} employee(s)
          </td>
        </tr>
        <tr>
          <td style="padding: 12px 18px; color: #64748b; font-size: 13px; font-weight: 600;">
            Scheduled Hours :
          </td>
          <td style="padding: 12px 18px; color: #0f172a; font-size: 14px; font-weight: 600;">
            ${u} hrs
          </td>
        </tr>
      </table>

      <!-- Callout -->
      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; margin: 16px 0;">
        <tr>
          <td style="padding: 14px 16px; color: #166534; font-size: 13px; line-height: 1.5;">
            <strong>Deadline Action:</strong> Please verify worked hours, resolve any attendance exceptions, and approve the timesheet before the payroll processing cutoff.
          </td>
        </tr>
      </table>

      <!-- Action Button -->
      <table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin: 24px 0 10px 0;">
        <tr>
          <td align="center">
            <a href="${$}/approval" style="display: inline-block; background-color: #4F46E5; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 700; font-size: 14px;">
              Review &amp; Approve Weekly Timesheet &rarr;
            </a>
          </td>
        </tr>
      </table>
    `,S=l({title:"Weekly Timesheet Approval Due",bodyHtml:z});for(let e of w){let a=await (0,r.sendEmailNotification)({to:e,subject:`Weekly Timesheet Approval Due: ${c} (${f}) — RotaBeat`,html:S,attachments:k});a.success&&t++,await i.prisma.notificationAuditLog.create({data:{type:"weekly_approval_reminder",recipient:e,siteId:o,weekStart:s,status:a.success?"SENT":"SIMULATED",reason:`Weekly approval reminder for ${c}, week of ${f}. ${h} employees, ${u} hrs.`}}).catch(()=>{})}}catch(e){console.error("sendWeeklyApprovalDueReminder error:",e)}return{sentCount:t}}e.s(["sendMissedClockInAlert",0,p,"sendUpcomingShiftReminders",0,s,"sendWeeklyApprovalDueReminder",0,c])}];

//# sourceMappingURL=lib_automated-emails_ts_0efnsum._.js.map