module.exports=[23227,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_managers_route_actions_0nbn6xl.js.map