module.exports=[50227,(e,o,r)=>{o.exports=e.x("node:path",()=>require("node:path"))},27028,(e,o,r)=>{o.exports=e.x("node:zlib",()=>require("node:zlib"))}];

//# sourceMappingURL=%5Bexternals%5D__0_1tcky._.js.map