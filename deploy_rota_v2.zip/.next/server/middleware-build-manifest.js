globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ve1uJ9MsnxW4qJ6kyx7qc/_buildManifest.js",
    "static/ve1uJ9MsnxW4qJ6kyx7qc/_ssgManifest.js",
    "static/ve1uJ9MsnxW4qJ6kyx7qc/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3e8dc9889dalm.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/1guzwd9wq_h9y.js",
    "static/chunks/244t6mh1n8u21.js",
    "static/chunks/turbopack-40ncknwlajj3a.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
