var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/managers/route.js")
R.c("server/chunks/[root-of-the-server]__0yiy5ar._.js")
R.c("server/chunks/_1qmr3gs._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/_next-internal_server_app_api_managers_route_actions_0nbn6xl.js")
R.m(79909)
module.exports=R.m(79909).exports
