var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/shifts/route.js")
R.c("server/chunks/[root-of-the-server]__1twt2mo._.js")
R.c("server/chunks/_13tzf0t._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_shifts_route_actions_17b4g9c.js")
R.m(67662)
module.exports=R.m(67662).exports
