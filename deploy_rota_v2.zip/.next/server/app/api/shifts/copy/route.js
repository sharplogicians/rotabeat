var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shifts/copy/route.js")
R.c("server/chunks/[root-of-the-server]__0g2-dva._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_shifts_copy_route_actions_0q3pfvj.js")
R.m(44409)
module.exports=R.m(44409).exports
