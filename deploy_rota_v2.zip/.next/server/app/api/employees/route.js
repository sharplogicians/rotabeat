var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/employees/route.js")
R.c("server/chunks/[root-of-the-server]__0h4a_om._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_1rd-t9d._.js")
R.c("server/chunks/_next-internal_server_app_api_employees_route_actions_1e27eln.js")
R.m(22892)
module.exports=R.m(22892).exports
