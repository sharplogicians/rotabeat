var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/payroll/route.js")
R.c("server/chunks/[root-of-the-server]__14g5udf._.js")
R.c("server/chunks/_0x6e_6c._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_payroll_route_actions_1dyz5os.js")
R.m(9977)
module.exports=R.m(9977).exports
