var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rota/copy-previous/route.js")
R.c("server/chunks/[root-of-the-server]__14e_cte._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_rota_copy-previous_route_actions_13vz8qn.js")
R.m(88867)
module.exports=R.m(88867).exports
