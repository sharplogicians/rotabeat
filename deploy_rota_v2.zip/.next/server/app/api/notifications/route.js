var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/lib_automated-emails_ts_1o4qaq-._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0gs121e._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_route_actions_1272ib8.js")
R.m(56032)
module.exports=R.m(56032).exports
