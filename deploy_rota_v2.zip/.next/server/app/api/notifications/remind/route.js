var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/remind/route.js")
R.c("server/chunks/node_modules_nodemailer_dist_esm_nodemailer_18vd7qm.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__181a57p._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_remind_route_actions_0n2i6pn.js")
R.m(10520)
module.exports=R.m(10520).exports
