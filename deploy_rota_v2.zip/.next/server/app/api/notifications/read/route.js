var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/read/route.js")
R.c("server/chunks/[root-of-the-server]__1v90ruu._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_read_route_actions_0e5djxq.js")
R.m(76297)
module.exports=R.m(76297).exports
