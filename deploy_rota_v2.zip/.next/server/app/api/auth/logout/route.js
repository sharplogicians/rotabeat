var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__1fwr6tc._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_route_actions_0regwyr.js")
R.m(43488)
module.exports=R.m(43488).exports
