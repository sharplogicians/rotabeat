var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__0u4xblc._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_17uv6xh.js")
R.m(28258)
module.exports=R.m(28258).exports
