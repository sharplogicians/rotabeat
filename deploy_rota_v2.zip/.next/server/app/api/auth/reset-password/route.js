var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/reset-password/route.js")
R.c("server/chunks/[root-of-the-server]__11ug1mn._.js")
R.c("server/chunks/_0jbuv6z._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_reset-password_route_actions_0ym3n2y.js")
R.m(18063)
module.exports=R.m(18063).exports
