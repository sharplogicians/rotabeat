var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/locations/route.js")
R.c("server/chunks/[root-of-the-server]__1yxmhf2._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_1o6tb77._.js")
R.c("server/chunks/_next-internal_server_app_api_locations_route_actions_0ekpsh_.js")
R.m(61486)
module.exports=R.m(61486).exports
