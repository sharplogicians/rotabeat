var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/approval/route.js")
R.c("server/chunks/[root-of-the-server]__1rc7osz._.js")
R.c("server/chunks/_0f4z7wm._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_approval_route_actions_1blf7q0.js")
R.m(66821)
module.exports=R.m(66821).exports
