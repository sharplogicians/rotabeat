var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/status/route.js")
R.c("server/chunks/[root-of-the-server]__0i01uxc._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_1edf5_d._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_status_route_actions_1i-012e.js")
R.m(72234)
module.exports=R.m(72234).exports
