var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/route.js")
R.c("server/chunks/[root-of-the-server]__0a4k6q_._.js")
R.c("server/chunks/_0nlp454._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_auth_ts_0ai-jfb._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_route_actions_1whc13v.js")
R.m(51309)
module.exports=R.m(51309).exports
