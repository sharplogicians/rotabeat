var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1ldqyt2._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0jiunqm._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_[id]_route_actions_1wl4o_9.js")
R.m(31178)
module.exports=R.m(31178).exports
