var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/[id]/audit/route.js")
R.c("server/chunks/[root-of-the-server]__1zmd-ru._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_[id]_audit_route_actions_1e38e6e.js")
R.m(14009)
module.exports=R.m(14009).exports
