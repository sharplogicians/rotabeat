var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/action/route.js")
R.c("server/chunks/[root-of-the-server]__1vrktyp._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0t3s7y3._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_action_route_actions_08-35y8.js")
R.m(41857)
module.exports=R.m(41857).exports
