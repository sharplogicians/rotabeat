var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/reminders/route.js")
R.c("server/chunks/_1k6czy2._.js")
R.c("server/chunks/lib_automated-emails_ts_0efnsum._.js")
R.c("server/chunks/[root-of-the-server]__1-ls3bk._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_reminders_route_actions_051v7sb.js")
R.m(51646)
module.exports=R.m(51646).exports
