:HL["/_next/static/chunks/3w67qjlrw52w2.css","style"]
:HL["/_next/static/chunks/2_fkoardzvi7p.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"ve1uJ9MsnxW4qJ6kyx7qc"}
