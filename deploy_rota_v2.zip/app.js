// Universal Phusion Passenger & Node.js HTTP Server for RotaBeat
const http = require('http');
const path = require('path');
const fs = require('fs');
const Module = require('module');

// Intercept Turbopack hashed externals like @prisma/client-[hash] and resolve to @prisma/client
const originalResolveFilename = Module._resolveFilename;
Module._resolveFilename = function (request, parent, isMain, options) {
  if (typeof request === 'string' && request.startsWith('@prisma/client-')) {
    return originalResolveFilename.call(this, '@prisma/client', parent, isMain, options);
  }
  return originalResolveFilename.call(this, request, parent, isMain, options);
};

// Polyfills for older Node versions if applicable
if (!Array.prototype.toSorted) {
  Array.prototype.toSorted = function(fn) { return [...this].sort(fn); };
}

const dir = path.resolve(__dirname);
process.env.NODE_ENV = 'production';
process.chdir(dir);

// Explicitly load .env file into process.env for Standalone runtime
try {
  const { loadEnvConfig } = require('@next/env');
  loadEnvConfig(dir);
} catch (e) {
  console.warn('Notice: @next/env load skipped, using fallback reader:', e.message);
}

// Fallback reader to guarantee all .env variables are present
try {
  const envFile = path.join(dir, '.env');
  if (fs.existsSync(envFile)) {
    const rawEnv = fs.readFileSync(envFile, 'utf-8');
    rawEnv.split(/?
/).forEach(function(line) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx > 0) {
        const key = trimmed.slice(0, eqIdx).trim();
        let val = trimmed.slice(eqIdx + 1).trim();
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        }
        if (!process.env[key]) {
          process.env[key] = val;
        }
      }
    });
  }
} catch (e) {}

if (process.env.DATABASE_URL) {
  const sanitized = process.env.DATABASE_URL.replace(/:([^:@]+)@/, ':****@');
  console.log('✅ Loaded DATABASE_URL from .env:', sanitized);
} else {
  console.warn('⚠️ WARNING: DATABASE_URL is not set in process.env!');
}

// Load Next.js configuration
let nextConfig = {};
try {
  const reqFilesPath = path.join(dir, '.next', 'required-server-files.json');
  if (fs.existsSync(reqFilesPath)) {
    const reqFiles = JSON.parse(fs.readFileSync(reqFilesPath, 'utf-8'));
    nextConfig = reqFiles.config || {};
  }
} catch (e) {
  console.warn('Warning loading required-server-files.json:', e.message);
}

nextConfig.outputFileTracingRoot = dir;
nextConfig.repoRoot = dir;
process.env.__NEXT_PRIVATE_STANDALONE_CONFIG = JSON.stringify(nextConfig);

const NextNodeServer = require('next/dist/server/next-server').default;
const nextServer = new NextNodeServer({
  dir,
  dev: false,
  conf: nextConfig,
  minimalMode: false,
});
const handler = nextServer.getRequestHandler();

const server = http.createServer(async (req, res) => {
  try {
    await handler(req, res);
  } catch (err) {
    console.error('Request handler error:', err);
    if (!res.headersSent) {
      res.statusCode = 500;
      res.end('Internal Server Error');
    }
  }
});

// Phusion Passenger detection & socket binding
if (typeof PhusionPassenger !== 'undefined') {
  console.log('Starting RotaBeat with Phusion Passenger...');
  server.listen('passenger');
} else {
  const port = process.env.PORT || 3000;
  console.log('Starting RotaBeat server on port ' + port + '...');
  server.listen(port);
}
